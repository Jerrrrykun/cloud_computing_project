import os
import boto3
import json
import re


# grab environment variables
ENDPOINT_NAME = 'blazingtext-2020-10-01-07-18-13-469'
runtime = boto3.Session().client('sagemaker-runtime')


def lambda_handler(event, context):
    #body = json.loads(event["body"])
    
    playload = {"instances" : (event["queryStringParameters"]["twitter"])}
    
    response = runtime.invoke_endpoint(EndpointName=ENDPOINT_NAME,
                                       ContentType='application/json',
                                       Body=json.dumps(playload))
    output = json.loads(response['Body'].read().decode('utf-8'))
    print(output[0]['prob'][0]*100)
    prob = output[0]['prob'][0]*100    
    label = output[0]['label'][0].split('__label__')[1]
    #print(label.split('__label__')[1])
    #predicted_label = 'True' if label == "FALSE" else 'True'
    #predicted_
    final_output = 'The predicted label is {} with a probability of {:.1f}%'.format(label, prob)
    return {
        'statusCode' : 200,
        'headers' : { 'Content-Type' : 'text/plain', 
                      'Access-Control-Allow-Origin' : '*' },
        'body' : json.dumps(final_output)
        }
