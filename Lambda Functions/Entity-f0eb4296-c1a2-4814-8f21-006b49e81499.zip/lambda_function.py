import os
import json
#from pprint import pprint
from botocore.vendored import requests

subscription_key = "ed3880d20cb048a2aba7fad3ca9e1201"
endpoint = "https://data-text-analytics.cognitiveservices.azure.com/"
def identify_entities(documents):
    entities_url = endpoint + "/text/analytics/v3.0/entities/recognition/general"
    headers = {"Ocp-Apim-Subscription-Key": subscription_key}
    response = requests.post(entities_url, headers=headers, json=documents)
    entities = response.json()
    return entities

def lambda_handler(event, context):
    # TODO implement
    text = event["queryStringParameters"]["twitter"]
    documents = {"documents": [
        {"id": "1", "language": "en",
            "text":  text}
    ]}
    response = identify_entities(documents)
    entities = response["documents"]
    return {
        'statusCode': 200,
        'body': json.dumps(entities)
    }
