import os
import json
#from pprint import pprint
from botocore.vendored import requests

subscription_key = "ed3880d20cb048a2aba7fad3ca9e1201"
endpoint = "https://data-text-analytics.cognitiveservices.azure.com/"

def sentiment_analysis_example(documents):
    sentiment_url = endpoint + "/text/analytics/v3.0/sentiment"
    headers = {"Ocp-Apim-Subscription-Key": subscription_key}
    response = requests.post(sentiment_url, headers=headers, json=documents)
    sentiments = response.json()
    return sentiments
        
def lambda_handler(event, context):
    text = event["queryStringParameters"]["twitter"]
    documents = {"documents": [
        {"id": "1", "language": "en",
            "text":  text}
    ]}
    response = sentiment_analysis_example(documents)
    sentiment = response["documents"]
    return {
        'statusCode' : 200,
        'headers' : { 'Content-Type' : 'text/plain', 
                      'Access-Control-Allow-Origin' : '*' },
        'body' : json.dumps(sentiment)
        }

