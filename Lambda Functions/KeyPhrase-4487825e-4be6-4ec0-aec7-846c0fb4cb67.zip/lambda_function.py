import json
import os
from botocore.vendored import requests
#from pprint import pprint

subscription_key = "ed3880d20cb048a2aba7fad3ca9e1201"
endpoint = "https://data-text-analytics.cognitiveservices.azure.com/"

def extract_key_phrases(documents):
    keyphrase_url = endpoint + "/text/analytics/v3.0/keyphrases"
    headers = {"Ocp-Apim-Subscription-Key": subscription_key}
    response = requests.post(keyphrase_url, headers=headers, json=documents)
    key_phrases = response.json()

    print("Printing key phrases ... \n")
    #pprint(key_phrases)
    return key_phrases

def lambda_handler(event, context):
    # TODO implement
    text = event["queryStringParameters"]["twitter"]
    documents = {"documents": [
        {"id": "1", "language": "en",
            "text":  text}
    ]}
    response = extract_key_phrases(documents)
    key_phrases = response["documents"][0]["keyPhrases"]
    return {
        'statusCode': 200,
        'body': json.dumps(key_phrases)
    }
